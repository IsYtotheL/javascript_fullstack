
const a = () => {
  console.log(123);
}
a();