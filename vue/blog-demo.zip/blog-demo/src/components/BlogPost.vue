<template>
  <div class="blogpost">
    <h2>{{post.title}}</h2>
    <p>{{post.body}}</p>
    <p>{{post.author}}</p>
  </div>
</template>

<script lang='ts'>
import { Vue, Prop, Component } from 'vue-property-decorator';
export interface Post {
  title: string;
  body: string;
  author: string;
  datePosted: Date;
}
@Component
export default class BlogPost extends Vue {
  @Prop() post!: Post
}
</script>

<style lang="stylus">
.blogpost
  h2
    text-decoration underline
</style>