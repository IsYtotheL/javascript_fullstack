const config = {
  database: {
      DATABASE: 'test',
      USERNAME: 'root',
      PASSWORD: 'xfwnxn1023',
      PORT: '3306',
      HOST: 'localhost'
  }
}

module.exports = config